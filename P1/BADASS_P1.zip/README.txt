Project: 'BADASS_P1' created on 2023-07-18
Author: chbadad <chbadad@student.42.fr>

P1 project for BADASS